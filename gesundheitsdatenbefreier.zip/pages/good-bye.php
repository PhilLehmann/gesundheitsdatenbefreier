<?php

defined('ABSPATH') or die('');

echo wpautop(get_option('gesundheitsdatenbefreier_good_bye_text'));
