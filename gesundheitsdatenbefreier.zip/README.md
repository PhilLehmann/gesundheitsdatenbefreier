# Der Gesundheitsdatenbefreier
Ein WordPress-Plugin, mit dem Versicherte ihre Daten dank DSGVO befreien können
