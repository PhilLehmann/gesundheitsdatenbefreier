== gesundheitsdatenbefreier ==
Plugin Name: gesundheitsdatenbefreier
Description: Ein WordPress-Plugin, mit dem Versicherte ihre Daten dank DSGVO befreien können
Version: 1.0
Author: Phil Lehmann, AK Vorratsdatenspeicherung
Author URI: http://www.vorratsdatenspeicherung.de/
Contributors: philrykoff
Tested up to: 5.2.4
Requires at least: 5.2.4
Requires PHP: 7.2.19
Stable tag: trunk